using UnityEngine;
using Game.Progress;  // ProgressManager / AreaIds を使う

public class StageClearRelay : MonoBehaviour
{
    [Header("このボタンで記録する Area / Stage")]
    public string areaId = AreaIds.Area_01;
    public int stage = 1;

    /// <summary>
    /// Button.OnClick から呼ぶ。ステージクリアを永続保存。
    /// 既にクリア済みなら second press 以降は new? False になる。
    /// </summary>
    public void MarkClear()
    {
        if (ProgressManager.Instance == null)
        {
            Debug.LogError("[StageClearRelay] ProgressManager not found.");
            return;
        }

        bool changed = ProgressManager.Instance.MarkStageCleared(areaId, stage);
        Debug.Log($"[Progress] {areaId} Stage {stage} cleared. (new? {changed})");
    }
}