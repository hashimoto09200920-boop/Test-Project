using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;
using Game.Progress; // ★ 重要：新しい ProgressManager の名前空間

public class ResetUI : MonoBehaviour
{
    [Header("任意：\"初期化しました\" の表示領域（無ければ未設定でOK）")]
    public GameObject messagePanel;

    [Header("任意：Reset 後に戻る先（UI_Root の SceneController を指す想定）")]
    public SceneController sceneController; // 無ければ Inspector で外してOK

    private bool waitingClickToBack = false;

    // 「Yes」ボタンに割り当てる
    public void OnClickYes()
    {
        if (ProgressManager.Instance == null)
        {
            Debug.LogError("[ResetUI] ProgressManager not found.");
            return;
        }

        // セーブデータ初期化
        ProgressManager.Instance.ResetAll();

        // メッセージ表示（任意）
        if (messagePanel != null) messagePanel.SetActive(true);

        // 右クリックで戻る待ち開始（仕様に合わせて Left にしたければ変更可）
        waitingClickToBack = true;
    }

    // 「No」ボタンに割り当てる（即 Menu 戻りなど）
    public void OnClickNo()
    {
        waitingClickToBack = false;
        if (messagePanel != null) messagePanel.SetActive(false);

        // 任意：Menu へ戻す（SceneController をアタッチしていれば）
        if (sceneController != null)
        {
            sceneController.BackToMenu();
        }
    }

    private void Update()
    {
        if (!waitingClickToBack) return;

        // 仕様に合わせてクリック種別を選ぶ（右クリック：GetMouseButtonDown(1)）
        if (Input.GetMouseButtonDown(1))
        {
            waitingClickToBack = false;
            if (messagePanel != null) messagePanel.SetActive(false);

            if (sceneController != null)
            {
                sceneController.BackToMenu();
            }
        }
    }
}