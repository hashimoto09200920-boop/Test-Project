using UnityEngine;

public class QuitConfirmUI : MonoBehaviour
{
    [SerializeField] GameObject quitPanel;
    [SerializeField] GameObject modalBlocker;   // ★ 追加
    [SerializeField] SceneController sceneController;

    void Awake()
    {
        if (quitPanel != null) quitPanel.SetActive(false);
        if (modalBlocker != null) modalBlocker.SetActive(false); // ★ 追加
        if (sceneController == null) sceneController = GetComponent<SceneController>();
    }

    // Quitボタンから呼ぶ
    public void ShowQuitConfirm()
    {
        if (modalBlocker != null) modalBlocker.SetActive(true); // ★ 追加
        if (quitPanel != null) quitPanel.SetActive(true);
    }

    // 「はい」
    public void OnClickQuitYes()
    {
        if (sceneController != null) sceneController.QuitGame();
    }

    // 「いいえ」
    public void OnClickQuitNo()
    {
        if (quitPanel != null) quitPanel.SetActive(false);
        if (modalBlocker != null) modalBlocker.SetActive(false); // ★ 追加
    }
}
