using UnityEngine;
using UnityEngine.SceneManagement;

public class SceneController : MonoBehaviour
{
    // Title → Menu
    public void GoToMenu()
    {
        SceneManager.LoadScene("02_Menu");
    }

    // Title → Reset（※番号は 06_Reset）
    public void GoToReset()
    {
        SceneManager.LoadScene("06_Reset");
    }

    // Quit 処理
    public void QuitGame()
    {
#if UNITY_EDITOR
        UnityEditor.EditorApplication.isPlaying = false;
#else
        Application.Quit();
#endif
    }

    // Title に戻る
    public void GoToTitle()
    {
        SceneManager.LoadScene("01_Title");
    }

    // Game に進む（※番号は 05_Game）
    public void GoToGame()
    {
        SceneManager.LoadScene("05_Game");
    }

    // Shop に進む（※番号は 07_Shop）
    public void GoToShop()
    {
        SceneManager.LoadScene("07_Shop");
    }

    // Relic に進む（※番号は 08_Relic）
    public void GoToRelic()
    {
        SceneManager.LoadScene("08_Relic");
    }

    // AreaSelect に進む（※番号は 03_AreaSelect）
    public void GoToAreaSelect()
    {
        SceneManager.LoadScene("03_AreaSelect");
    }

    // UnitSelect に進む（※番号は 04_UnitSelect）
    public void GoToUnitSelect()
    {
        SceneManager.LoadScene("04_UnitSelect");
    }

    // 戻り用（Menu に戻る）
    public void BackToMenu()
    {
        SceneManager.LoadScene("02_Menu");
    }

    // 戻り用（Title に戻る）
    public void BackToTitle()
    {
        SceneManager.LoadScene("01_Title");
    }
}
